*****Robux2Money*****
---------------------------------------------------------
Created by: Frenchtoast0 (Roblox.com)


Description:
This chrome extension converts your Robux amount
to your specified currency.

---------------------------------------------------------
Date of conversion data: May 26, 2020
*Warning: conversion values may change over time*

Devex rate: 100,000 Robux for $350 USD = 0.0035 USD
